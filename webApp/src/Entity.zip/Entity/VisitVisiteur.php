<?php

namespace App\Entity;

use App\Repository\VisitVisiteurRepository;
use App\Entity\Visite;
use App\Entity\Visiteur;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

#[ORM\Entity(repositoryClass: VisitVisiteurRepository::class)]
class VisitVisiteur
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[Groups(['visite:item'])]
    private ?int $id = null;

    #[ORM\Column]
    #[Groups(['visite:item'])]
    #[Groups(['visite:item', 'visit:update'])]
    private ?bool $present = null;

    #[Groups(['visite:item'])]
    #[Groups(['visite:item', 'visit:update'])]
    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $commentaire = null;

    #[Groups(['visite:item'])]
    #[ORM\ManyToOne(inversedBy: 'visitVisiteurs')]
    private ?Visite $visite = null;

    #[Groups(['visite:item'])]
    #[ORM\ManyToOne(inversedBy: 'visitVisiteurs')]
    private ?Visiteur $visiteur = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function isPresent(): ?bool
    {
        return $this->present;
    }

    public function setPresent(bool $present): static
    {
        $this->present = $present;

        return $this;
    }

    public function getCommentaire(): ?string
    {
        return $this->commentaire;
    }

    public function setCommentaire(?string $commentaire): static
    {
        $this->commentaire = $commentaire;

        return $this;
    }

    public function getVisite(): ?Visite
    {
        return $this->visite;
    }

    public function setVisite(?Visite $visite): static
    {
        $this->visite = $visite;

        return $this;
    }

    public function getVisiteur(): ?Visiteur
    {
        return $this->visiteur;
    }

    public function setVisiteur(?Visiteur $visiteur): static
    {
        $this->visiteur = $visiteur;

        return $this;
    }
}
